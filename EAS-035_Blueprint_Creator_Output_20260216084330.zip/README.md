# Project Structure

This project is structured to support automated testing using Cypress.

## Directories

- `cypress/`: Contains Cypress test cases and supporting functions.
- `cypress/integration/`: Directory for test cases.
- `cypress/support/`: Directory for supporting functions.

## Files

- `README.md`: Project documentation.
