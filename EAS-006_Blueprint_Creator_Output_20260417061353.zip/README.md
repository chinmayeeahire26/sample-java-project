# EAS-006 Blueprint Creator Output

This project is a ready-to-extend **Cypress E2E automation skeleton (JIRA-oriented)**.

## What’s included
- Cypress configuration (`cypress.config.js`)
- Example E2E spec (`cypress/e2e/example-jira-search.cy.js`)
- Support commands/helpers (`cypress/support/commands.js`, `cypress/support/utils/jira-api.js`)
- Fixtures and environment template (`cypress/fixtures`, `cypress.env.example.json`)

## Prerequisites
- Node.js 18+ recommended
- Access to a JIRA Cloud instance (Atlassian)

## Setup
1. Install dependencies:

```bash
npm ci
```

2. Create your local environment file:

```bash
cp cypress.env.example.json cypress.env.json
```

3. Edit `cypress.env.json` with your values.

> Security note: **Do not commit** `cypress.env.json`. Store secrets in CI secret managers.

## Running
Interactive mode:

```bash
npm run cy:open
```

Headless mode:

```bash
npm run cy:run
# or
npm test
```

## Notes
- `baseUrl` can be set via `CYPRESS_BASE_URL` in CI.
- The provided tests are intentionally safe and generic.
- For JIRA API tests, ensure `JIRA_EMAIL` and `JIRA_API_TOKEN` are configured.