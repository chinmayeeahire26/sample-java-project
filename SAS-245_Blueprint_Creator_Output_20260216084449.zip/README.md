# Project Documentation

This is the root of the project structure for the Cypress automation project.