# sample_page.py

from .base_page import BasePage

class SamplePage(BasePage):
    def click_button(self, button_selector: str):
        self.page.click(button_selector)

    def get_element_text(self, element_selector: str) -> str:
        return self.page.inner_text(element_selector)
