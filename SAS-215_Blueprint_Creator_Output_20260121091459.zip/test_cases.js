describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Example Domain');
  });

  it('should have a title', () => {
    cy.title().should('include', 'Example Domain');
  });

  it('should navigate to another page', () => {
    cy.get('a').click();
    cy.url().should('include', '/another-page');
  });
});