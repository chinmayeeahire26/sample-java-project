# jira

This project contains Cypress tests and supporting functions for automation testing related to jira.