# Project Structure
This project contains Cypress test cases and supporting functions.