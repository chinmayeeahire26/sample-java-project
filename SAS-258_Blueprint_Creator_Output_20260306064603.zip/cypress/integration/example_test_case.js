// Example Cypress test case
describe('Example Test', () => {
  it('should perform a test', () => {
    // test code here
  });
});