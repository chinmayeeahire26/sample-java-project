// Cypress Support Functions

// Function to log in to the application
function login(username, password) {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

// Function to log out from the application
function logout() {
  cy.get('#logout-button').click();
}

// Export functions for use in test cases
module.exports = {
  login,
  logout
};
