describe('Sample Test Suite', () => {
  it('should visit the application home page', () => {
    cy.visit('https://example.com');
    cy.url().should('include', 'example.com');
  });

  it('should find the login button', () => {
    cy.get('#login-button').should('be.visible');
  });

  it('should login successfully', () => {
    cy.get('#username').type('testuser');
    cy.get('#password').type('password');
    cy.get('#login-button').click();
    cy.url().should('include', '/dashboard');
  });
});