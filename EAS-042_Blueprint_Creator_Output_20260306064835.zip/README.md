# Project Structure

This project contains the following components:

- Cypress
- Starting Test Case
- Supporting Functions
- TEST
