// supporting_functions.js

// This file contains supporting functions for Cypress tests

/**
 * Function to log in to the application
 * @param {string} username - The username for login
 * @param {string} password - The password for login
 */
function login(username, password) {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#loginButton').click();
}

/**
 * Function to log out from the application
 */
function logout() {
  cy.get('#logoutButton').click();
}

/**
 * Function to navigate to a specific page
 * @param {string} pageUrl - The URL of the page to navigate to
 */
function navigateTo(pageUrl) {
  cy.visit(pageUrl);
}

module.exports = {
  login,
  logout,
  navigateTo
};