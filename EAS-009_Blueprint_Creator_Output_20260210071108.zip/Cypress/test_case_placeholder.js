// Cypress Test Case

describe('My First Test', () => {
  it('Visits the Cypress.io page', () => {
    cy.visit('https://www.cypress.io')
    cy.contains('cypress.io')
  })
})
