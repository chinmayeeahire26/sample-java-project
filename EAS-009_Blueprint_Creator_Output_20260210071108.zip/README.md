# Project Documentation
This is the root of the project structure.