using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SeleniumSampleTest
{
    class Program
    {
        // Variables (Settings)
        static string url = "https://www.example.com/login";
        static string usernameFieldId = "username"; // Example element ID for username input
        static string passwordFieldId = "password"; // Example element ID for password input
        static string loginButtonId = "loginButton"; // Example element ID for login button
        static string username = "testuser";
        static string password = "testpassword";

        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            try
            {
                // Navigate to URL
                driver.Navigate().GoToUrl(url);
                driver.Manage().Window.Maximize();

                // Enter username
                IWebElement usernameField = driver.FindElement(By.Id(usernameFieldId));
                usernameField.SendKeys(username);

                // Enter password
                IWebElement passwordField = driver.FindElement(By.Id(passwordFieldId));
                passwordField.SendKeys(password);

                // Click login button
                IWebElement loginButton = driver.FindElement(By.Id(loginButtonId));
                loginButton.Click();

                // Wait for some time to see results (replace with explicit waits in real tests)
                System.Threading.Thread.Sleep(3000);

                Console.WriteLine("Login test completed successfully.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("Element not found: " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Test failed: " + e.Message);
            }
            finally
            {
                driver.Quit();
            }
        }
    }
}
