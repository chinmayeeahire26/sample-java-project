// Support functions
