// Example test case
