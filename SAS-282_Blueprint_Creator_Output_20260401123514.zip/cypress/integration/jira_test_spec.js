describe('Jira Test Suite', () => {
  it('should run a sample test', () => {
    cy.visit('https://example.cypress.io')
    cy.contains('type').click()
    cy.url().should('include', '/commands/actions')
  })
})
