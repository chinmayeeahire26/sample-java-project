describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('/')
    cy.contains('Welcome')
  })
})
