describe('Jira Test Suite', () => {
  it('should run a sample Jira related test', () => {
    cy.visit('https://jira.example.com');
    cy.contains('Log In').should('be.visible');
  });
});
