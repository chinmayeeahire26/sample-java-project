// Supporting functions for Cypress test cases

// Example function to log in
function login(username, password) {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

// Example function to log out
function logout() {
  cy.get('#logout-button').click();
}

module.exports = {
  login,
  logout
};