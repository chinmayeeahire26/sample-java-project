// Example test case

describe('Example Test', () => {
  it('should visit the app', () => {
    cy.visit('/');
  });
});