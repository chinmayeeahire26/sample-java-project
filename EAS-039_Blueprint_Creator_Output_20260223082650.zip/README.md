# Project Structure

This project contains the following structure:

- Cypress
  - Starting Test Case
  - Supporting Functions
- test
