describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Welcome to Example');
  });
});