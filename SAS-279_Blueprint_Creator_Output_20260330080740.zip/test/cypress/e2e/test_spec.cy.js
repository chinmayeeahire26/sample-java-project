describe('Starting Test Case', () => {
  it('should visit the example page and check title', () => {
    cy.visit('/')
    cy.title().should('include', 'Example')
  })
})
