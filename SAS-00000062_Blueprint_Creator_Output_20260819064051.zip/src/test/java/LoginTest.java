import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginTest {
    // methodName: loginToLaptop1
    public void loginToLaptop1() {
        // Set the path to the chromedriver executable
        System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");

        // Setup Chrome options
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // Run headless for automation

        WebDriver driver = new ChromeDriver(options);

        try {
            // Navigate to the login page of Laptop1
            driver.get("http://laptop1.local/login");

            // Locate username and password fields and login button
            WebElement usernameField = driver.findElement(By.id("username"));
            WebElement passwordField = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("loginBtn"));

            // Enter credentials
            usernameField.sendKeys("admin");
            passwordField.sendKeys("password123");

            // Click login
            loginButton.click();

            // Wait for some element that confirms login success (simple sleep here for demo)
            Thread.sleep(3000);

            // Verify login success by checking page title or element
            if(driver.getTitle().contains("Dashboard")) {
                System.out.println("Login to Laptop1 successful.");
            } else {
                System.out.println("Login to Laptop1 failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
