describe('JIRA Automation Test Suite', () => {
  before(() => {
    // Runs once before all tests in the block
    cy.log('Starting Test Case: JIRA Automation');
  });

  beforeEach(() => {
    // Runs before each test
    cy.visit('/');
  });

  it('should login successfully with valid credentials', () => {
    cy.login('testuser@example.com', 'password123');
    cy.url().should('include', '/dashboard');
  });

  it('should create a new JIRA issue', () => {
    // Assuming the app has a form to create issues
    cy.get('#create-issue-button').click();
    cy.get('#issue-title').type('Test Issue from Cypress');
    cy.get('#issue-description').type('This issue was created during automated testing.');
    cy.get('#submit-issue').click();
    cy.contains('Issue created successfully').should('be.visible');
  });

  it('should display the list of JIRA issues', () => {
    cy.get('#issues-list').should('be.visible');
    cy.get('#issues-list').children().should('have.length.greaterThan', 0);
  });

  after(() => {
    cy.log('Completed Test Case: JIRA Automation');
  });
});
