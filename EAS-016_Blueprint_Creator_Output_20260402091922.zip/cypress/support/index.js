// Support commands and utilities

Cypress.Commands.add('login', (email, password) => {
  cy.request('POST', '/login', { email, password }).then((response) => {
    expect(response.status).to.eq(200);
    window.localStorage.setItem('authToken', response.body.token);
  });
});

Cypress.Commands.add('logout', () => {
  window.localStorage.removeItem('authToken');
  cy.visit('/logout');
});

Cypress.Commands.add('resetTestEnvironment', () => {
  cy.request('POST', '/test/reset');
});

// You can add more custom commands here
