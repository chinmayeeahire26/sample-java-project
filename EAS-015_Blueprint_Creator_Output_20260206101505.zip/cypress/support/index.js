// support/index.js
// This file is processed and loaded automatically before your test files.
// You can use this file to load global configurations and behavior that modifies Cypress.

import './commands'

// Example of a custom command to log into the application
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/login')
  cy.get('input[name=username]').type(username)
  cy.get('input[name=password]').type(password)
  cy.get('button[type=submit]').click()
})

// Example of a custom command to logout
Cypress.Commands.add('logout', () => {
  cy.get('button.logout').click()
})