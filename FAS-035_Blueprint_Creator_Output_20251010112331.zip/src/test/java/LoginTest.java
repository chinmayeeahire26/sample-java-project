import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class LoginTest {
   @Test
   public void testLogin() {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.flipkart.com");

        // Close initial login modal
        WebElement closeLoginModal = driver.findElement(By.xpath("//button[contains(text(),'✕')]");
        closeLoginModal.click();

        // Perform login steps
        WebElement loginButton = driver.findElement(By.xpath("..."));
        // Add other actions required for login
        // Assertions to verify login success

        driver.quit();
   }
}