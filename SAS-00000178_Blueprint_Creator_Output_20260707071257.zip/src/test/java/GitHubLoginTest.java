import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.time.Duration;

public class GitHubLoginTest {

    public void loginToGithub() {
        // Set the path to chromedriver executable if needed
        // System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // Run headless for automation
        WebDriver driver = new ChromeDriver(options);

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.get("https://github.com/login");

            // Enter username
            WebElement usernameField = driver.findElement(By.id("login_field"));
            usernameField.sendKeys("your_username");

            // Enter password
            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("your_password");

            // Click sign in button
            WebElement signInButton = driver.findElement(By.name("commit"));
            signInButton.click();

            // Add verification or assertions here if needed
            System.out.println("Login attempted to GitHub");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }

    public static void main(String[] args) {
        GitHubLoginTest test = new GitHubLoginTest();
        test.loginToGithub();
    }
}
