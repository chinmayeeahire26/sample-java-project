// Cypress Test Case

describe('Sample Test Case', () => {
  it('should visit the page and check the title', () => {
    cy.visit('https://example.com');
    cy.title().should('include', 'Example Domain');
  });
});