// Cypress Test Case

describe('Sample Test Suite', () => {
  it('should visit the example page and check the title', () => {
    cy.visit('https://example.cypress.io');
    cy.title().should('include', 'Cypress');
  });

  // Supporting function example
  function checkElement(selector) {
    cy.get(selector).should('be.visible');
  }

  it('should check if the header is visible', () => {
    checkElement('h1');
  });
});