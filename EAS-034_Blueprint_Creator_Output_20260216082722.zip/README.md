# Project Structure

This project is structured to support Cypress testing with organized test cases and supporting functions.
