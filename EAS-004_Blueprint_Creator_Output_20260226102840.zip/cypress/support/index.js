// cypress/support/index.js

// Supporting Functions
function logMessage(message) {
  cy.log(message);
}

function navigateTo(url) {
  cy.visit(url);
}

// Starting Test Case
describe('Sample Test Suite', () => {
  it('should navigate to a page and log a message', () => {
    navigateTo('https://example.com');
    logMessage('Navigated to example.com');
    
    // Additional assertions can be added here
    cy.get('h1').should('contain', 'Example Domain');
  });
});

module.exports = {
  logMessage,
  navigateTo
};