// Example test case

describe('Example Test Suite', () => {
  it('should visit the app', () => {
    cy.visit('/');
  });
});