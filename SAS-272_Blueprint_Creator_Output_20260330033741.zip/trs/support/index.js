// Supporting functions for trs project

export function helper() {
  return true;
}

export function visitHomePage() {
  cy.visit('/');
}

export function isVisible(selector) {
  return cy.get(selector).should('be.visible');
}
