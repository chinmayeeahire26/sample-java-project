import { visitHomePage, isVisible } from '../support/index';

describe('Sample Test Suite', () => {
  beforeEach(() => {
    visitHomePage();
  });

  it('should load the home page and check visibility of main content', () => {
    // Assuming the home page has an element with id 'main-content'
    isVisible('#main-content');
  });

  it('should pass a simple true equality test', () => {
    expect(true).to.equal(true);
  });
});
