# trs Project

This is the trs test automation project using Cypress framework.

## Project Structure

- `cypress.json`: Cypress configuration file.
- `support/index.js`: Supporting functions for tests.
- `tests/sample_test.spec.js`: Sample test cases.

## How to Run Tests

1. Install dependencies: `npm install cypress`
2. Run tests: `npx cypress open` or `npx cypress run`

## Description

This project contains automated tests using Cypress for web application testing.
Supporting functions are provided in the support folder to assist test cases.