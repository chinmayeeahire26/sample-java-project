package com.example.tests;

import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

public class SampleTest {
    @Test
    public void sampleTest() {
        assertTrue(true);
    }
}