# SAS-283 Blueprint Creator Output

This project contains Cypress test automation structure and supporting test files.
