// Utility functions for Jira automation tests

const jiraConfig = require('../config/jira_config.json');

function log(message) {
  console.log(`[LOG]: ${message}`);
}

function getAuthHeader() {
  const auth = Buffer.from(`${jiraConfig.username}:${jiraConfig.apiToken}`).toString('base64');
  return `Basic ${auth}`;
}

module.exports = { log, getAuthHeader };
