/// <reference types="cypress" />

const jiraConfig = require('../config/jira_config.json');
const { log } = require('../support/utils');

// Cypress test suite for Jira automation

describe('Jira Automation Test Suite', () => {
  it('should create a new Jira issue via API successfully', () => {
    const auth = Buffer.from(`${jiraConfig.username}:${jiraConfig.apiToken}`).toString('base64');
    const issueData = {
      fields: {
        project: {
          key: jiraConfig.projectKey
        },
        summary: 'Automated test issue from Cypress',
        description: 'Creating an issue using Cypress test automation',
        issuetype: {
          name: 'Task'
        }
      }
    };

    cy.request({
      method: 'POST',
      url: `${jiraConfig.jiraUrl}/rest/api/2/issue`,
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/json'
      },
      body: issueData
    }).then((response) => {
      log(`Response status: ${response.status}`);
      expect(response.status).to.eq(201);
      expect(response.body).to.have.property('key');
      log(`Created issue key: ${response.body.key}`);
    });
  });
});
