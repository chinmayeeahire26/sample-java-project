# jira Automation Project

This project contains automation test cases and supporting functions related to Jira integration and testing.

## Structure

- tests/: Contains test cases
- support/: Contains supporting functions and utilities
- config/: Configuration files for Jira and test environment

## Usage

Run tests using the test runner configured in this project.