/// <reference types="cypress" />

describe('Starting Test Case: Sample Login Test', () => {
  beforeEach(() => {
    // Runs before each test in the block
    cy.visit('/');
  });

  it('should login successfully with valid credentials', () => {
    cy.login('testuser', 'password123');
    // Verify successful login by checking URL or element
    cy.url().should('include', '/dashboard');
    cy.contains('Welcome, testuser').should('be.visible');
  });

  it('should show error on invalid login', () => {
    cy.login('testuser', 'wrongpassword');
    cy.get('.error-message').should('contain', 'Invalid username or password');
  });
});
