# Cypress Test Automation Project

This project contains Cypress test cases and supporting functions for automation testing.
