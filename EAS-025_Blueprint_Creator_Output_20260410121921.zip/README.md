# jira Test Automation Project

This project contains automated tests and supporting functions for jira-related testing using Cypress framework.

## Project Structure

- cypress/
  - integration/
  - support/
- tests/
- cypress.json
- package.json

## How to run tests

Run `npm install` to install dependencies.
Run `npx cypress open` to open Cypress Test Runner.
Run `npx cypress run` to execute tests in headless mode.
