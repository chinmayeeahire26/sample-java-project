from playwright.sync_api import sync_playwright

# Test setup script

def setup():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        return page
