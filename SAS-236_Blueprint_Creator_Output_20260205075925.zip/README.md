# Project Structure

This project is structured based on Playwright with Python guidelines, including Test Setup, Page Objects, Test Cases, Assertions, and Reporting.