# Jira Test Automation Project

This project contains test automation scripts and configurations related to Jira.