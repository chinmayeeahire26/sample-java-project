// Supporting functions for Jira automation

Cypress.Commands.add('createJiraIssue', (summary, description) => {
  const auth = Buffer.from(`${Cypress.env('jiraUsername')}:${Cypress.env('jiraApiToken')}`).toString('base64');
  cy.request({
    method: 'POST',
    url: '/rest/api/3/issue',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/json'
    },
    body: {
      fields: {
        project: {
          key: Cypress.env('jiraProjectKey')
        },
        summary: summary,
        description: description,
        issuetype: {
          name: 'Task'
        }
      }
    }
  }).then((response) => {
    expect(response.status).to.eq(201);
    cy.wrap(response.body.key).as('issueKey');
  });
});
