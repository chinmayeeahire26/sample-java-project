/// <reference types="cypress" />

describe('Jira Issue Creation', () => {
  it('should create a new Jira issue successfully', () => {
    const summary = 'Test issue from Cypress automation';
    const description = 'This issue was created by an automated Cypress test.';

    cy.createJiraIssue(summary, description);

    cy.get('@issueKey').then((issueKey) => {
      cy.log('Created issue key:', issueKey);
      expect(issueKey).to.match(/^TEST-\d+$/);
    });
  });
});
