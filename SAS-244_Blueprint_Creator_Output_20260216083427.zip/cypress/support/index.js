// Support functions for Cypress tests
