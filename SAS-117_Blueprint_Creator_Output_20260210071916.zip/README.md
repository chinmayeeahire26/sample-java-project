# Project Documentation

This project contains the structure for Cypress testing, starting test cases, and supporting functions.
