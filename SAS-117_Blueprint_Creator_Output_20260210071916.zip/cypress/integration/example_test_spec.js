// example_test_spec.js

describe('Example Test Suite', () => {
  it('should visit the application and check the title', () => {
    cy.visit('https://example.com');
    cy.title().should('include', 'Example Domain');
  });

  // Supporting function
  function customCommand() {
    cy.log('This is a custom command');
  }

  it('should use a custom command', () => {
    customCommand();
  });
});