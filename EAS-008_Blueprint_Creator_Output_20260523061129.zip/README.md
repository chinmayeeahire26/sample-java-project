# Jira Automation Project

This project contains automation tests and supporting functions related to Jira.