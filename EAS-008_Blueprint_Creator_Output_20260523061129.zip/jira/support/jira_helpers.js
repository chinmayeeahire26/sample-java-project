// Helper functions for Jira automation

function createIssuePayload(summary, description) {
  return {
    fields: {
      summary: summary,
      description: description,
      issuetype: { name: 'Bug' },
      project: { key: 'TEST' }
    }
  };
}

module.exports = { createIssuePayload };