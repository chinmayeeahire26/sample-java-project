# SAS-025 Blueprint Creator Output

This project contains test automation scripts and configuration files for Jira and Cypress integration.
