/// <reference types="cypress" />

describe('Jira Issue Tests', () => {
  before(() => {
    // Runs once before all tests in the block
    cy.log('Starting Jira Issue Tests');
  });

  beforeEach(() => {
    // Runs before each test
    cy.visit('https://jira.example.com'); // Replace with actual Jira URL
  });

  it('should load the Jira login page', () => {
    cy.url().should('include', 'jira');
    cy.get('#login-form-username').should('be.visible');
    cy.get('#login-form-password').should('be.visible');
  });

  it('should login successfully with valid credentials', () => {
    cy.loginToJira(Cypress.env('JIRA_USERNAME'), Cypress.env('JIRA_PASSWORD'));
    cy.url().should('not.include', 'login');
    cy.get('#header-details-user-fullname').should('be.visible');
  });

  it('should create a new Jira issue', () => {
    cy.loginToJira(Cypress.env('JIRA_USERNAME'), Cypress.env('JIRA_PASSWORD'));
    cy.createJiraIssue('Test Issue from Cypress', 'This is a test issue created by Cypress automation');
    cy.get('.aui-message-success').should('contain', 'has been created');
  });
});
