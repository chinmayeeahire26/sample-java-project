// Custom commands for Jira automation

Cypress.Commands.add('loginToJira', (username, password) => {
  cy.get('#login-form-username').type(username);
  cy.get('#login-form-password').type(password, { log: false });
  cy.get('#login').click();
  cy.url().should('not.include', 'login');
});

Cypress.Commands.add('createJiraIssue', (summary, description) => {
  cy.get('#create_link').click();
  cy.get('#summary').type(summary);
  cy.get('#description').type(description);
  cy.get('#create-issue-submit').click();
  cy.get('.aui-message-success').should('be.visible');
});
