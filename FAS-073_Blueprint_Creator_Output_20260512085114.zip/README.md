# Keeper Login Automation

This project contains a Selenium WebDriver automation script in Java to perform login actions on the Keeper application.

## Project Structure

- `src/main/java/com/keeper/automation/LoginAutomation.java`: Main Java class containing the Selenium automation script.

## Prerequisites

- Java JDK installed
- Selenium WebDriver dependencies
- ChromeDriver executable path set correctly in the script

## Usage

1. Update the ChromeDriver path in `LoginAutomation.java`.
2. Build and run the Java program to execute the login automation.

This project is generated based on provided blueprint guidelines and automation instructions.
