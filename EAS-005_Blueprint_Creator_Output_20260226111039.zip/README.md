# Project Structure
This directory contains the project structure for the Cypress automation with test cases and supporting functions.