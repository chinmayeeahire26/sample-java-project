describe('Sample Test Case', () => {
  it('should perform a simple test', () => {
    cy.visit('https://example.cypress.io')
    cy.contains('type').click()
    cy.url().should('include', '/commands/actions')
  })
})
