# Project Structure

This project is structured based on the blueprint guidelines and automation instructions.

## Directories
- cypress/
- test/

## Files
- README.md
