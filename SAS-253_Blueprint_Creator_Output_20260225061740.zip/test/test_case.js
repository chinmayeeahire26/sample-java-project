// Cypress Test Case

// Supporting Functions
function login() {
  cy.visit('/login');
  cy.get('#username').type('admin');
  cy.get('#password').type('password');
  cy.get('#login-button').click();
}

// Test Case
describe('Login Test', () => {
  it('should log in successfully', () => {
    login();
    cy.url().should('include', '/dashboard');
  });
});
