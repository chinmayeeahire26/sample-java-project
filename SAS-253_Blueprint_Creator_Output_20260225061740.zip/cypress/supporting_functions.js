// Supporting functions for Cypress tests
