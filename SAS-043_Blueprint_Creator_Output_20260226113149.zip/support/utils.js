// utils.js

// Cypress Supporting Functions

/**
 * Function to log into the application
 * @param {string} username - The username for login
 * @param {string} password - The password for login
 */
function login(username, password) {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

/**
 * Function to log out of the application
 */
function logout() {
  cy.get('#logout-button').click();
}

module.exports = {
  login,
  logout
};