# SAS-335 Blueprint Creator Output

This project contains automated test cases and supporting functions for Jira-related testing using Cypress.