/// <reference types="cypress" />

describe('Jira Issue Tests', () => {
  before(() => {
    // Runs once before all tests in the block
    cy.log('Starting Jira Issue Tests');
  });

  beforeEach(() => {
    // Runs before each test
    cy.visit('https://jira.example.com');
  });

  it('should load the Jira login page', () => {
    cy.url().should('include', 'jira.example.com');
    cy.get('input#login-form-username').should('be.visible');
    cy.get('input#login-form-password').should('be.visible');
  });

  it('should allow user to login with valid credentials', () => {
    cy.get('input#login-form-username').type(Cypress.env('JIRA_USERNAME'));
    cy.get('input#login-form-password').type(Cypress.env('JIRA_PASSWORD'), { log: false });
    cy.get('#login').click();
    cy.url().should('not.include', 'login');
    cy.contains('Dashboard').should('be.visible');
  });

  it('should create a new issue', () => {
    cy.loginToJira();
    cy.get('#create_link').click();
    cy.get('#summary').type('Test issue created by Cypress automation');
    cy.get('#create-issue-submit').click();
    cy.contains('has been created').should('be.visible');
  });
});
