// ***********************************************************
// This example support/index.js is processed and
// loaded automatically before your test files.
//
// You can put global configuration and behavior that modifies Cypress here.
//
// Import commands.js using ES2015 syntax:
// import './commands'

// Alternatively you can use CommonJS syntax:
// require('./commands')

// Custom command to login to Jira
Cypress.Commands.add('loginToJira', () => {
  cy.visit('https://jira.example.com/login.jsp');
  cy.get('input#login-form-username').type(Cypress.env('JIRA_USERNAME'));
  cy.get('input#login-form-password').type(Cypress.env('JIRA_PASSWORD'), { log: false });
  cy.get('#login').click();
  cy.url().should('not.include', 'login');
  cy.contains('Dashboard').should('be.visible');
});

// You can add more supporting functions here
