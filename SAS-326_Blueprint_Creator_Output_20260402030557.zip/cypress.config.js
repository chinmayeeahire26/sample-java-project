const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://example.cypress.io',
    supportFile: 'cypress/support/supporting_functions.js',
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
});
