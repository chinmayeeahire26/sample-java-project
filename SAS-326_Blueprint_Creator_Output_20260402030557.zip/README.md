# SAS-326 Blueprint Creator Output

This project contains automated test cases and supporting functions based on the provided blueprint guidelines and automation instructions.

## Structure
- cypress/
  - integration/
  - support/

## Purpose
To provide a starting point for Cypress test cases and supporting functions for automation testing.
