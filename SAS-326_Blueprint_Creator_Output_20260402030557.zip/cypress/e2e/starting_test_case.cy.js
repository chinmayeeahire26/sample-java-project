import { customCommand } from '../support/supporting_functions';

describe('Starting Test Case', () => {
  before(() => {
    // Setup code if needed
  });

  it('should visit the example page and perform a test', () => {
    cy.visit('/');
    cy.contains('type').click();
    cy.url().should('include', '/commands/actions');
    // Use a supporting function
    customCommand();
  });
});
