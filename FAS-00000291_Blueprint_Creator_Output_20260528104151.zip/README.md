# FAS UI Automation (Selenium + Java + TestNG)

## Purpose
Automates UI validation for the test case:
- Attempt to edit a prompt with invalid data that causes an error.
- Expected: An error message is displayed in the snackbar indicating the edit failure.

## Tech Stack
- Java 17
- Selenium 4
- TestNG
- WebDriverManager

## Run
```bash
mvn -q test
```

## Configuration
Edit runtime properties in:
- `src/test/resources/config.properties`

Override via JVM system properties if needed:
```bash
mvn test -DbaseUrl=https://your-app.example -Dbrowser=chrome
```