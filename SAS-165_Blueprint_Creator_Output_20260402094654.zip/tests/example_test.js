// Cypress test case for JIRA

describe('JIRA Issue Page Tests', () => {
  const jiraBaseUrl = 'https://jira.example.com';
  const issueKey = 'SAS-165';

  it('should load the JIRA issue page successfully', () => {
    cy.visit(`${jiraBaseUrl}/browse/${issueKey}`);
    cy.contains(issueKey).should('be.visible');
    cy.get('h1').should('contain.text', issueKey);
  });

  it('should have a comment section', () => {
    cy.visit(`${jiraBaseUrl}/browse/${issueKey}`);
    cy.get('#issue-comments').should('exist');
  });
});
