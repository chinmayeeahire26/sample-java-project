// Supporting utility functions for JIRA and Cypress tests

/**
 * Constructs a JIRA issue URL given the base URL and issue key
 * @param {string} baseUrl - The base URL of the JIRA instance
 * @param {string} issueKey - The JIRA issue key
 * @returns {string} - Full URL to the JIRA issue
 */
function getJiraIssueUrl(baseUrl, issueKey) {
  if (!baseUrl || !issueKey) {
    throw new Error('Both baseUrl and issueKey are required');
  }
  return `${baseUrl.replace(/\/$/, '')}/browse/${issueKey}`;
}

/**
 * Validates a JIRA issue key format (e.g., ABC-123)
 * @param {string} issueKey
 * @returns {boolean}
 */
function isValidIssueKey(issueKey) {
  const regex = /^[A-Z]+-\d+$/;
  return regex.test(issueKey);
}

module.exports = { getJiraIssueUrl, isValidIssueKey };
