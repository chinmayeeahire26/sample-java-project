// sample_test.js

// Import necessary Cypress commands
import { expect } from 'chai';

// Describe the test suite
describe('Sample Test Suite', () => {
  // Before each test, visit the homepage
  beforeEach(() => {
    cy.visit('https://example.com');
  });

  // Test case: Check if the homepage loads successfully
  it('should load the homepage', () => {
    cy.url().should('include', 'example.com');
    cy.get('h1').should('contain', 'Welcome to Example');
  });

  // Test case: Check if a button is visible
  it('should display the main button', () => {
    cy.get('#main-button').should('be.visible');
  });

  // Supporting function: Custom command to log in
  Cypress.Commands.add('login', (username, password) => {
    cy.get('#username').type(username);
    cy.get('#password').type(password);
    cy.get('#login-button').click();
  });

  // Test case using the supporting function
  it('should log in successfully', () => {
    cy.login('testuser', 'password123');
    cy.get('#welcome-message').should('contain', 'Welcome, testuser');
  });
});
