module.exports = (on, config) => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config

  // You can modify the config object here
  // 
  // Example setup: adding custom tasks
  on('task', {
    exampleTask() {
      console.log('This is an example task');
      return null;
    }
  });
  
  return config;
};