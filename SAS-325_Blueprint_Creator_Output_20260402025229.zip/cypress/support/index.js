// Support functions for Cypress tests

Cypress.Commands.add('login', (username, password) => {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('button[type=submit]').click();
});

Cypress.Commands.add('logout', () => {
  cy.get('#logout').click();
});

Cypress.Commands.add('isLoggedIn', () => {
  cy.get('body').then($body => {
    if ($body.find('#logout').length > 0) {
      return true;
    } else {
      return false;
    }
  });
});
