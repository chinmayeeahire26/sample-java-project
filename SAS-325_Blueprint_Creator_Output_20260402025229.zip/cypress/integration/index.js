// Jira Login Test Case

describe('Jira Login Test Suite', () => {
  beforeEach(() => {
    cy.visit('/login');
  });

  it('should login successfully with valid credentials', () => {
    cy.login('testuser', 'password123');
    cy.url().should('include', '/dashboard');
    cy.contains('Welcome, testuser').should('be.visible');
  });

  it('should fail login with invalid credentials', () => {
    cy.login('invaliduser', 'wrongpassword');
    cy.get('.error-message').should('contain', 'Invalid username or password');
  });

  it('should logout successfully', () => {
    cy.login('testuser', 'password123');
    cy.url().should('include', '/dashboard');
    cy.logout();
    cy.url().should('include', '/login');
  });
});
