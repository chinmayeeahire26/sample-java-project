# SAS-325 Blueprint Creator Output

This project contains automated test cases and supporting functions for Jira-related testing using the Cypress framework.

## Project Structure

- `cypress.json`: Cypress configuration file.
- `cypress/integration/index.js`: Contains the main test cases for Jira.
- `cypress/support/index.js`: Contains custom Cypress commands and support functions.

## How to Run Tests

1. Install dependencies: `npm install cypress`
2. Run tests: `npx cypress open` or `npx cypress run`

## Test Description

The test suite includes login functionality tests for Jira, verifying successful login and dashboard redirection.

## Supporting Functions

Custom Cypress commands are defined to facilitate login and other reusable actions.