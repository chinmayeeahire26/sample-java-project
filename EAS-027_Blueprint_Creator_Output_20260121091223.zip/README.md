# Project Overview

This project is structured to support automation testing using Cypress. It includes directories for test cases, scripts, and configuration files.

- **test_cases**: Contains all the test case files.
- **scripts**: Contains automation scripts.
- **config**: Contains configuration files necessary for running the tests.
