// Support commands and configurations

Cypress.Commands.add('login', () => {
  // Example login implementation
  cy.visit('/login')
  cy.get('input[name="username"]').type(Cypress.env('username') || 'testuser')
  cy.get('input[name="password"]').type(Cypress.env('password') || 'password123')
  cy.get('button[type="submit"]').click()
  cy.url().should('not.include', '/login')
})

Cypress.Commands.add('createIssue', (title, description) => {
  cy.visit('/jira/new-issue')
  cy.get('input[name="title"]').type(title)
  cy.get('textarea[name="description"]').type(description)
  cy.get('button[type="submit"]').click()
  cy.contains('Issue created successfully').should('be.visible')
})

Cypress.Commands.add('searchIssue', (query) => {
  cy.visit('/jira')
  cy.get('input[placeholder="Search issues"]').type(`${query}{enter}`)
  cy.contains(query).should('be.visible')
})
