describe('Jira Issue Tracker Tests', () => {
  beforeEach(() => {
    // Assuming login is required before tests
    cy.login()
  })

  it('should visit the Jira dashboard and verify the presence of issues', () => {
    cy.visit('/jira')
    cy.contains('Issues')
    cy.get('.issue-list').should('exist')
  })

  it('should create a new Jira issue', () => {
    cy.visit('/jira/new-issue')
    cy.get('input[name="title"]').type('Test Issue from Cypress')
    cy.get('textarea[name="description"]').type('This issue was created by an automated Cypress test.')
    cy.get('button[type="submit"]').click()
    cy.contains('Issue created successfully').should('be.visible')
  })

  it('should search for an existing Jira issue', () => {
    cy.visit('/jira')
    cy.get('input[placeholder="Search issues"]').type('Test Issue from Cypress{enter}')
    cy.contains('Test Issue from Cypress').should('be.visible')
  })
})
