// This is the support file for Cypress tests
import './commands';
