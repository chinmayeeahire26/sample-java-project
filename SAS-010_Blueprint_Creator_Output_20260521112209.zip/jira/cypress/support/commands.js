// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
// ***********************************************

// Custom command to login to JIRA
Cypress.Commands.add('login', (username, password) => {
  cy.request({
    method: 'POST',
    url: '/rest/auth/1/session',
    body: {
      username: username,
      password: password
    }
  }).then((response) => {
    expect(response.status).to.eq(200);
    cy.setCookie('JSESSIONID', response.body.session.value);
  });
});

// Custom command to get issue details
Cypress.Commands.add('getIssue', (issueId) => {
  cy.request({
    method: 'GET',
    url: `/rest/api/2/issue/${issueId}`
  }).then((response) => {
    expect(response.status).to.eq(200);
    return response.body;
  });
});
