import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AjioLoginTest {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.ajio.com");

        // Locate login elements and perform actions
        WebElement loginButton = driver.findElement(By.id("loginButton"));
        loginButton.click();

        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement submitButton = driver.findElement(By.id("submit"));

        usernameField.sendKeys("testuser");
        passwordField.sendKeys("password");
        submitButton.click();

        // Validate login success
        WebElement successMessage = driver.findElement(By.id("successMessage"));
        if(successMessage.isDisplayed()) {
            System.out.println("Login Test Passed");
        } else {
            System.out.println("Login Test Failed");
        }

        driver.quit();
    }
}