# Jira Test Automation Project

This project contains automated tests related to Jira functionalities.

Folders:
- tests: Contains test scripts
- config: Configuration files
- docs: Documentation
