// utils.js

// Supporting functions for Cypress test cases

// Function to log in to the application
function login(username, password) {
  cy.visit('/login');
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

// Function to check if an element is visible
function isVisible(selector) {
  cy.get(selector).should('be.visible');
}

// Function to log out from the application
function logout() {
  cy.get('#logout-button').click();
}

module.exports = {
  login,
  isVisible,
  logout
};