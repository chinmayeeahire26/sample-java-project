describe('Jira Test Suite', () => {
  it('should run a sample test', () => {
    cy.visit('/')
    cy.contains('Welcome')
  })
})