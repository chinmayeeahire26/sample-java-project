# Jira Test Automation Project

This project contains automated tests and supporting functions for Jira-related testing.

## Structure

- tests/: Contains test case scripts
- data/: Contains test data files
- utils/: Contains utility and helper functions

## Usage

Run the tests using your preferred test runner.
