// commands.js - Cypress custom commands for Jira

Cypress.Commands.add('login', (username, password) => {
  cy.visit('https://jira.example.com/login');
  cy.get('input[name="username"]').type(username);
  cy.get('input[name="password"]').type(password);
  cy.get('button[type="submit"]').click();
  cy.url().should('not.include', '/login');
});

Cypress.Commands.add('createIssue', (title, description) => {
  cy.get('button#create-issue').click();
  cy.get('input[name="summary"]').type(title);
  cy.get('textarea[name="description"]').type(description);
  cy.get('button[type="submit"]').click();
});
