/// <reference types="cypress" />

// jira_spec.js - Cypress test for Jira related functionality

describe('Jira Issue Tests', () => {
  before(() => {
    // Setup code if needed
    cy.log('Starting Jira tests');
  });

  beforeEach(() => {
    // Runs before each test
    cy.visit('https://jira.example.com'); // Replace with actual Jira URL
  });

  it('should load the Jira login page', () => {
    cy.get('input[name="username"]').should('be.visible');
    cy.get('input[name="password"]').should('be.visible');
  });

  it('should fail login with invalid credentials', () => {
    cy.get('input[name="username"]').type('invalidUser');
    cy.get('input[name="password"]').type('invalidPass');
    cy.get('button[type="submit"]').click();
    cy.contains('Incorrect username or password').should('be.visible');
  });

  it('should create a new issue using supporting function', () => {
    cy.login('validUser', 'validPass');
    cy.createIssue('Test Issue from Cypress', 'This is a test issue created by Cypress automation');
    cy.contains('Issue created successfully').should('be.visible');
  });
});
