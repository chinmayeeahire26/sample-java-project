// jira_spec.js - Cypress test case for JIRA related functionality

const { login, clearSession } = require('../support/helper');

describe('JIRA Automation Test Suite', () => {
  beforeEach(() => {
    clearSession();
    cy.visit('https://example-jira-instance.com/login');
  });

  it('Starting Test Case: should login successfully', () => {
    login('testuser', 'testpassword');
    // Verify successful login by checking URL or element
    cy.url().should('include', '/dashboard');
    cy.get('.welcome-message').should('contain', 'Welcome');
  });
});
