// helper.js - Supporting functions for Cypress tests

/**
 * Logs in a user with given username and password
 * @param {string} username
 * @param {string} password
 */
function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('button[type=submit]').click();
}

/**
 * Clears all cookies and local storage
 */
function clearSession() {
  cy.clearCookies();
  cy.clearLocalStorage();
}

module.exports = {
  login,
  clearSession
};
