describe('Example Test Suite', () => {
  it('Visits the Cypress.io website', () => {
    cy.visit('https://www.cypress.io');
    cy.contains('JavaScript End to End Testing Framework');
  });
});
