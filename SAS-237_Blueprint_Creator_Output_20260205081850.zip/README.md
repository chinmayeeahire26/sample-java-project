# Project Overview

This project uses Cypress for end-to-end testing.

## Getting Started

To run the tests, ensure you have Node.js installed and run the following commands:

```bash
npm install
npx cypress open
```

## Project Structure

- `cypress/integration`: Contains test cases.
- `support/functions`: Contains supporting functions for tests.
