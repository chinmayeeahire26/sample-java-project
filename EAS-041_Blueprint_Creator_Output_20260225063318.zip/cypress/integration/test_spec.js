// test_spec.js

describe('Jira Test Suite', () => {
  before(() => {
    // Setup code if needed
    cy.visit('https://jira.example.com'); // Replace with actual Jira URL
  });

  it('should log in to Jira', () => {
    cy.get('#login-form-username').type('your-username'); // Replace with actual username
    cy.get('#login-form-password').type('your-password'); // Replace with actual password
    cy.get('#login').click();
    cy.url().should('include', '/dashboard');
  });

  it('should create a new issue', () => {
    cy.get('#create_link').click();
    cy.get('#summary').type('New Issue Summary');
    cy.get('#description').type('Detailed description of the issue.');
    cy.get('#create-issue-submit').click();
    cy.contains('Issue Created').should('be.visible');
  });

  after(() => {
    // Teardown code if needed
    cy.get('#header-details-user-fullname').click();
    cy.get('#log_out').click();
  });
});