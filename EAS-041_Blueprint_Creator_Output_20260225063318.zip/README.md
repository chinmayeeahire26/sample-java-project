# Project Structure

This project is structured to support Cypress testing with starting test cases and supporting functions.
