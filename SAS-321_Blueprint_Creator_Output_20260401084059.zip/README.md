# Jira Test Automation Project

This project contains test automation scripts and resources related to Jira testing.

## Structure
- tests/: Test cases
- scripts/: Automation scripts
- docs/: Documentation
