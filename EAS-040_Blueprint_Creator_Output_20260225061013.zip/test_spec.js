// Cypress Test Case

describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Welcome to Example');
  });

  it('should have a login button', () => {
    cy.get('#login-button').should('be.visible');
  });
});

// Supporting Functions
function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

module.exports = { login };
