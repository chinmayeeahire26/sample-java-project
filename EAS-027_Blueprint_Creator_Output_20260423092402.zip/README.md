# EAS-027 Jira Cypress Blueprint

Enterprise-ready Cypress end-to-end test starter targeting Jira (Cloud or Server/Data Center). The structure is intentionally minimal but robust, with:

- A **starting smoke spec**
- **Supporting functions** (custom commands + helper utilities)
- Example fixture data
- Configuration via environment variables (recommended for CI)

## Prerequisites

- Node.js 18+
- Access to a Jira instance (URL + user + API token/password)

## Install

```bash
npm install
```

## Configuration

This project reads configuration from environment variables (preferred) or from Cypress `env`.

Required:

- `JIRA_BASE_URL` (e.g. `https://company.atlassian.net`)
- `JIRA_USERNAME` (email/username)
- `JIRA_API_TOKEN` (API token/password, depending on deployment)
- `JIRA_PROJECT_KEY` (e.g. `ABC`)

Example (macOS/Linux):

```bash
export JIRA_BASE_URL="https://company.atlassian.net"
export JIRA_USERNAME="user@company.com"
export JIRA_API_TOKEN="***"
export JIRA_PROJECT_KEY="ABC"
```

Example (Windows PowerShell):

```powershell
$env:JIRA_BASE_URL="https://company.atlassian.net"
$env:JIRA_USERNAME="user@company.com"
$env:JIRA_API_TOKEN="***"
$env:JIRA_PROJECT_KEY="ABC"
```

## Run

Open Cypress UI:

```bash
npm run cy:open
```

Run headlessly:

```bash
npm run cy:run
```

## Notes / Adaptation Guidance

- Jira login differs by deployment (Cloud vs Server/DC) and may be protected by SSO.
  - If SSO is enabled, UI login may not be feasible in Cypress. Consider API-based authentication (cookie injection) or disabling SSO for test users.
- Selectors vary by Jira version; selectors are centralized in `cypress/support/utils/jira.js`.
- Keep secrets out of the repo. Use environment variables or a CI secret store.