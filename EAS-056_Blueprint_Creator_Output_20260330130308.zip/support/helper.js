// Supporting helper functions for Jira tests

export function logTestStart(testName) {
  cy.log(`Starting test: ${testName}`);
}

export function login(username, password) {
  cy.get('#login-form-username').type(username);
  cy.get('#login-form-password').type(password);
  cy.get('#login').click();
  cy.url().should('include', '/secure/Dashboard.jspa');
}
