# Jira Automation Test Project

This project contains automated test cases and supporting functions for Jira-related testing using Cypress framework.

## Structure
- tests/: Contains test case files
- support/: Contains supporting functions and utilities

## Usage
Run tests using Cypress test runner.