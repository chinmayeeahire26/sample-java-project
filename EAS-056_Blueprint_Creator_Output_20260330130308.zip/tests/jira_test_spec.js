import { logTestStart } from '../support/helper';

describe('Jira Issue Test', () => {
  beforeEach(() => {
    cy.visit('https://your-jira-instance-url.com'); // Replace with actual Jira URL
  });

  it('should create a new Jira issue', () => {
    logTestStart('should create a new Jira issue');

    // Login steps - replace selectors and credentials accordingly
    cy.get('#login-form-username').type('your-username');
    cy.get('#login-form-password').type('your-password');
    cy.get('#login').click();

    // Wait for dashboard to load
    cy.url().should('include', '/secure/Dashboard.jspa');

    // Navigate to create issue
    cy.get('#create_link').click();

    // Fill in issue details - replace selectors accordingly
    cy.get('#summary').type('Automated test issue');
    cy.get('#description').type('This issue was created by an automated Cypress test.');

    // Submit the issue
    cy.get('#create-issue-submit').click();

    // Verify issue creation success message
    cy.get('.aui-message-success').should('contain', 'has been created');
  });
});
