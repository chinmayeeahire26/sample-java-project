# Project: EAS-038 Blueprint Creator Output

This project is set up for Cypress testing automation.

## Structure

- cypress/
  - integration/
  - support/
- package.json
- cypress.json

## Instructions

This project is ready for code integration and testing using Cypress.
