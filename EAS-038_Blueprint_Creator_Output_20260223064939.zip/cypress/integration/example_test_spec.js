// example_test_spec.js

// Basic Cypress test case

describe('Example Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Example Domain');
  });
});
