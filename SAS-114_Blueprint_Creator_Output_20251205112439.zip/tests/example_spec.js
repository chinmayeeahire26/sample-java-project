/// <reference types="cypress" />

describe('Cypress Test Suite', () => {
  it('Visits the app home page', () => {
    cy.visit('/')
    cy.contains('Welcome')
  })
})