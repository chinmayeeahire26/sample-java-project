// Jira integration configuration
module.exports = {
  jiraHost: 'https://your-jira-instance.atlassian.net',
  projectKey: 'TEST',
  auth: {
    username: 'your-username',
    apiToken: 'your-api-token'
  }
};
