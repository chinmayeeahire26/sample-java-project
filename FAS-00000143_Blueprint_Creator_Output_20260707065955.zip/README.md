# Hub Login Automation Project

This project contains automation scripts for testing the login functionality to the hub.
