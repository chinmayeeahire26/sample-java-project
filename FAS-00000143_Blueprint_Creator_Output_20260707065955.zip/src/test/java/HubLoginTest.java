import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HubLoginTest {
    // methodName: loginToHub
    public void loginToHub() {
        // Setup ChromeDriver (assumes chromedriver is in system PATH)
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // Run headless for automation
        WebDriver driver = new ChromeDriver(options);
        try {
            // Navigate to hub login page
            driver.get("https://example-hub-login.com/login");

            // Locate username and password fields and login button
            WebElement usernameField = driver.findElement(By.id("username"));
            WebElement passwordField = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("loginBtn"));

            // Enter credentials
            usernameField.sendKeys("testuser");
            passwordField.sendKeys("testpassword");

            // Click login
            loginButton.click();

            // Add verification step (e.g., check for logout button or user profile)
            Thread.sleep(2000); // wait for page to load
            boolean loggedIn = driver.findElements(By.id("logoutBtn")).size() > 0;
            if (loggedIn) {
                System.out.println("Login successful.");
            } else {
                System.out.println("Login failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }

    public static void main(String[] args) {
        HubLoginTest test = new HubLoginTest();
        test.loginToHub();
    }
}
