public class AjioLoginTest {
    public void testLogin() {
        System.out.println("Executing login test");
        // Add Selenium WebDriver code here for login test
    }
}