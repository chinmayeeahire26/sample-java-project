describe('Starting Test Case', () => {
  it('should visit the homepage', () => {
    cy.visit('/')
    cy.contains('Welcome')
  })
})
