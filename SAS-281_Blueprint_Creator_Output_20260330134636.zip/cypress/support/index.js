// Support functions for Jira Cypress tests

// Custom command to login to Jira
Cypress.Commands.add('login', (username, password) => {
  cy.get('input#login-form-username').type(username);
  cy.get('input#login-form-password').type(password);
  cy.get('#login').click();
});

// Custom command to check for login error
Cypress.Commands.add('checkLoginError', () => {
  cy.get('#login-form-error').should('contain.text', 'Sorry, your username and password are incorrect');
});

// Export any helper functions if needed
module.exports = {};
