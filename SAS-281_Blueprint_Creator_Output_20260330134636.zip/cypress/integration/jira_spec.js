/// <reference types="cypress" />

describe('Jira Test Suite', () => {
  before(() => {
    // Runs once before all tests in the block
    cy.log('Starting Jira Test Suite');
  });

  beforeEach(() => {
    // Runs before each test
    cy.visit('https://jira.example.com');
  });

  it('should load the Jira login page', () => {
    cy.get('input#login-form-username').should('be.visible');
    cy.get('input#login-form-password').should('be.visible');
  });

  it('should display error on invalid login', () => {
    cy.get('input#login-form-username').type('invalidUser');
    cy.get('input#login-form-password').type('invalidPass');
    cy.get('#login').click();
    cy.get('#login-form-error').should('contain.text', 'Sorry, your username and password are incorrect');
  });
});
