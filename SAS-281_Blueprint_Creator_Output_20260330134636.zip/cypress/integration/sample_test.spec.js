describe('Sample Test', () => {
  it('should visit the Jira homepage', () => {
    cy.visit('https://jira.atlassian.com');
    cy.contains('Jira');
  });
});
