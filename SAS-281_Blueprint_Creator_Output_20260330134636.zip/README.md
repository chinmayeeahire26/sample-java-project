# Jira Cypress Test Automation Project

This project contains Cypress test cases and supporting functions for Jira-related test automation.

## Structure

- cypress/integration: Test cases
- cypress/support: Supporting functions

## Usage

Run Cypress tests using `npx cypress open` or `npx cypress run`.
