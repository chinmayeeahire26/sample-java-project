// Supporting Functions

// Custom command to perform login
Cypress.Commands.add('login', (email, password) => {
  cy.get('input[name=email]').type(email)
  cy.get('input[name=password]').type(password)
  cy.get('form').submit()
})

// Custom command to clear and type text into an input field
Cypress.Commands.add('clearAndType', (selector, text) => {
  cy.get(selector).clear().type(text)
})
