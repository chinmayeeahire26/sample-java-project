export function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

export function logout() {
  cy.get('#logout-button').click();
}