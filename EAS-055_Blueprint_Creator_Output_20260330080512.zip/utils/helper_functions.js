// Helper functions for test automation

function logMessage(message) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] LOG: ${message}`);
}

function waitForElement(selector, timeout = 10000) {
  cy.get(selector, { timeout }).should('be.visible');
}

module.exports = { logMessage, waitForElement };
