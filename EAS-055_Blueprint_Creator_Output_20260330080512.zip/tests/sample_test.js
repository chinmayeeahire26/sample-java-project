// Cypress test case using helper functions
const { logMessage } = require('../utils/helper_functions');

describe('Starting Test Case: Sample Test Suite', () => {
  before(() => {
    logMessage('Starting the test suite');
  });

  it('should visit example.com and check title', () => {
    cy.visit('https://example.com');
    cy.title().should('include', 'Example Domain');
    logMessage('Visited example.com and verified title');
  });

  it('should have a visible heading', () => {
    cy.get('h1').should('be.visible').and('contain.text', 'Example Domain');
    logMessage('Verified heading is visible and correct');
  });

  after(() => {
    logMessage('Test suite completed');
  });
});
