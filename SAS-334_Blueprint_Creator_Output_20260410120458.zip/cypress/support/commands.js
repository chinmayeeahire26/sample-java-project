// Supporting functions for Jira tests

Cypress.Commands.add('login', (username, password) => {
  cy.log(`Logging in as ${username}`);
  // Add login steps here
});
