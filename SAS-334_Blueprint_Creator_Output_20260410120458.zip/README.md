# Jira Test Automation Project

This project contains automated tests for Jira using Cypress framework.

## Project Structure

- cypress/integration: Test cases
- cypress/support: Supporting functions

## How to run tests

1. Install dependencies: `npm install`
2. Run tests: `npx cypress open` or `npx cypress run`

## Notes

This project is structured to support Jira test automation scenarios.
