# Project Documentation

This project structure is created based on Cypress automation guidelines and initial test case setup.
