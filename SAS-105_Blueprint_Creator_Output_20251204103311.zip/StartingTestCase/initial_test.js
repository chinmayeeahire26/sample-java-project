describe('Initial Test Suite', () => {
  it('Should load the homepage', () => {
    cy.visit('https://example.com');
    cy.get('h1').contains('Welcome to Example.com');
  });
  
  it('Should display the login form', () => {
    cy.get('#login').should('be.visible');
  });
});