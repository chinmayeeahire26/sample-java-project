# Project: JIRA Automation

This project is structured to facilitate automated testing using Cypress.
