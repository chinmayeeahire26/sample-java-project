# Project Structure

This project is set up for automation testing using Cypress.

- **test_cases/**: Contains test cases for the application.
- **supporting_functions/**: Contains supporting functions used in test cases.
