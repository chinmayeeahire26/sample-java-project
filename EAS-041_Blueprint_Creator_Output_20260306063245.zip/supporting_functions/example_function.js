// Example supporting function

function exampleFunction() {
  return 'Hello, World!';
}

module.exports = exampleFunction;
