/// <reference types="cypress" />

import { loginToJira } from '../support/utils';

describe('Jira Automation Test Suite', () => {
  before(() => {
    // Runs once before all tests in the block
    cy.visit('https://your-jira-instance-url.com');
  });

  it('Starting Test Case: Login to Jira and verify dashboard', () => {
    loginToJira('testuser', 'testpassword');
    // Verify that dashboard loads
    cy.get('#dashboard').should('be.visible');
  });

  it('Create a new Jira issue', () => {
    // Assuming user is logged in
    cy.get('#create_link').click();
    cy.get('#summary').type('Test issue created by Cypress automation');
    cy.get('#create-issue-submit').click();
    // Verify issue creation success message
    cy.contains('has been successfully created').should('be.visible');
  });
});
