# Jira Test Automation Project

This project contains automated tests related to Jira functionalities.

## Structure
- tests/: Contains test cases
- support/: Contains supporting functions and utilities
- cypress.json: Configuration file for Cypress

## Usage
Run tests using Cypress test runner.